from flask import Flask,flash, render_template, request,url_for,redirect,Response,session,send_file,send_from_directory
from datetime import datetime
from functools import wraps
from flask_mysqldb import MySQL
from werkzeug.utils import secure_filename

import os
import random
import csv
import pandas as pd
import numpy as np
import json

app=Flask(__name__)
app.config['MYSQL_HOST']='localhost'
app.config['MYSQL_USER']='root'
app.config['MYSQL_PASSWORD']=''
app.config['MYSQL_DB']='db_tourism'
app.config['MYSQL_CURSORCLASS']='DictCursor'
mysql=MySQL(app)

now = datetime.now()

#define function for convert yyyy-mm-dd to dd-mm-yyyy
def format_datetime(value, format="%d-%m-%Y"):
    if value is None:
        return ""
    return datetime.strptime(value,"%Y-%m-%d").strftime(format)

#configured Jinja2 environment with user defined
app.jinja_env.filters['date_format']=format_datetime

UPLOAD_FOLDER='static/images'
FILE_EXTENSIONS = {'png', 'jpg', 'jpeg'}

def allowed_extensions(file_name):
    return '.' in file_name and file_name.rsplit('.',1)[1].lower() in FILE_EXTENSIONS


#Login
@app.route('/') 
@app.route('/index',methods=['POST','GET'])
def index():
    return render_template("index.html")
 
#Login
@app.route('/admin',methods=['POST','GET'])
def admin():
    msg=''
    if request.method=='POST':
        email=request.form["aname"]
        pwd=request.form["apass"]
        cur=mysql.connection.cursor()
        cur.execute("select * from admin where aname=%s and apass=%s",(email,pwd))
        data=cur.fetchone()
        if data:
            session['logged_in']=True
            session['aid']=data["aid"]
            session['aname']=data["aname"]
            return redirect('admin_home')
        else:
            msg='Invalid Login. Try Again'
    return render_template("admin.html",msg=msg)

@app.route('/admin_home',methods=['POST','GET'])
def admin_home():
    if request.method=='POST':
        cate=request.form['cate']
        cur=mysql.connection.cursor()
        cur.execute("INSERT INTO category (cname) values(%s)" ,((cate),))
        mysql.connection.commit()
        cur.close()
        flash('Details Added Successfully','success')
    cur=mysql.connection.cursor()
    cur.execute("select * from category")
    data=cur.fetchall()
    return render_template("admin_home.html",data=data)	


@app.route('/add_place',methods=['POST','GET'])
def add_place():

    if request.method=='POST':
    
        cid=request.form['cid']    
        pname=request.form['pname']    
        loc=request.form['loc']    
        des=request.form['des']    
        file = request.files['file']

        if file and allowed_extensions(file.filename):
            filename, file_extension = os.path.splitext(file.filename)
            new_filename = secure_filename(str(random.randint(10000,99999))+"."+file_extension)
            file.save(os.path.join(UPLOAD_FOLDER, new_filename))   

            cur=mysql.connection.cursor()
            cur.execute("INSERT INTO `place`(`cid`, `pname`, `loc`, `des`, `pimg`) VALUES (%s,%s,%s,%s,%s)", (cid,pname,loc,des,new_filename))
            mysql.connection.commit()
            cur.close()    
            flash('Details Added Successfully','success')
            
    cur=mysql.connection.cursor()
    cur.execute("select * from category")
    category=cur.fetchall()
    return render_template("add_place.html",category=category)	


@app.route('/delete_cate/<string:cid>',methods=['GET','POST'])
def delete_cate(cid):
    cur=mysql.connection.cursor()
    cur.execute("delete from category where cid=%s",(cid,))
    mysql.connection.commit()
    cur.close()
    return redirect(url_for("admin_home"))
    
@app.route('/user',methods=['POST','GET'])
def user():
    return render_template("user.html")	


@app.route('/view_user',methods=['POST','GET'])
def view_user():
    cur=mysql.connection.cursor()
    cur.execute("select * from user")
    data=cur.fetchall()	
    return render_template("view_user.html",data=data)

@app.route('/change_password',methods=['POST','GET'])
def change_password():
	if request.method=='POST':
		if request.form['submit']=='Submit':  
			npass=request.form['npass']
			cpass=request.form['cpass']
			cur=mysql.connection.cursor()
			if npass==cpass:
				cur.execute("update `admin` set  `apass`=%s where aid=%s",(npass,session['aid']))
				mysql.connection.commit()
				cur.close()
				flash('Password Updated','info')
			else:
				flash('New password and conform password must be same','danger')
	return render_template("change_password.html")
    
@app.route('/user_delete/<string:ud>',methods=['GET','POST'])
def user_delete(ud):
    cur=mysql.connection.cursor()
    cur.execute("delete from user where ud=%s",(ud,))
    mysql.connection.commit()
    cur.close()
    flash('User Deleted Successfully','Danger')
    return redirect(url_for("view_user"))

@app.route('/user_home',methods=['POST','GET'])
def user_home():
    cur=mysql.connection.cursor()
    cur.execute("select * from user where ud=%s",(session["ud"],))
    data=cur.fetchall()	
    return render_template("user_home.html",data=data)

@app.route('/send_request',methods=['POST','GET'])
def send_request():
    cur=mysql.connection.cursor()
    cur.execute("select * from user  where ud=%s  ",(session["ud"],))
    user=cur.fetchone()	
    
    cur=mysql.connection.cursor()
    cur.execute("select * from user  where ud!=%s  ",(session["ud"],))
    all_users=cur.fetchall()	
    
    cur=mysql.connection.cursor()
    cur.execute("SELECT tid FROM request WHERE fid = %s   UNION SELECT fid FROM request WHERE tid = %s ",(session["ud"] ,session['ud']))
    friends = cur.fetchall()
    friend_ids = {friend['tid'] if 'tid' in friend else friend['fid'] for friend in friends}
    
  
    available_users = [user for user in all_users if user['ud'] not in friend_ids]
    
    return render_template("send_request.html",  users=available_users)


@app.route('/user_request/<string:ud>',methods=['POST','GET'])
def user_request(ud):
    cur=mysql.connection.cursor()
    cur.execute("INSERT INTO request(fid,tid,rdate,status) VALUES  (%s,%s,NOW(),%s)",(session["ud"],ud,'Pending'))
    mysql.connection.commit()
    cur.close()
    flash('Request Added','success')
    return redirect(url_for("send_request"))

@app.route('/accept/<string:rid>',methods=['POST','GET'])
def accept(rid):
    cur=mysql.connection.cursor()
    cur.execute("update request set status=%s where rid=%s",('Accepted',rid))
    mysql.connection.commit()
    cur.close()
    flash('Request Accepted','Success')
    return redirect(url_for("view_request"))

@app.route('/reject/<string:rid>',methods=['POST','GET'])
def reject(rid):
    cur=mysql.connection.cursor()
    cur.execute("delete from request  where rid=%s",(rid,))
    mysql.connection.commit()
    cur.close()
    flash("Request Rejected",'Success')
    return redirect(url_for("view_request"))    

@app.route('/view_request',methods=['POST','GET'])
def view_request():
    cur=mysql.connection.cursor()
    cur.execute("select * from request r inner join user u on r.fid=u.ud where r.tid=%s and r.status=%s",(session["ud"],'Pending'))
    data=cur.fetchall()	
    return render_template("view_request.html",data=data) 


    

@app.route('/add_post',methods=['POST','GET'])
def add_post():
    
    if request.method=='POST':
    
        cid=request.form['cid']    
        pname=request.form['pname']        
        des=request.form['des']    
        file = request.files['file']

        if file and allowed_extensions(file.filename):
            filename, file_extension = os.path.splitext(file.filename)
            new_filename = secure_filename(str(random.randint(10000,99999))+"."+file_extension)
            file.save(os.path.join(UPLOAD_FOLDER, new_filename))   

            cur=mysql.connection.cursor()
            cur.execute("INSERT INTO `post`(`ud`,`cid`,`pdate`, `ptitle`, `pimage`, `desp`) VALUES (%s,%s,NOW(),%s,%s,%s)", (session["ud"],cid,pname,new_filename,des))
            mysql.connection.commit()
            cur.close()    
            flash('Post Added Successfully','success')
            
    cur=mysql.connection.cursor()
    cur.execute("select * from category")
    category=cur.fetchall()
    
    cur=mysql.connection.cursor()
    cur.execute("select * from post p inner join user u on p.ud=u.ud where u.ud=%s",(session["ud"],))
    data=cur.fetchall()	
    
    return render_template("add_post.html",category=category,data=data)	

@app.route('/view_post',methods=['POST','GET'])
def view_post():
    cur=mysql.connection.cursor()
    cur.execute("select pid,pname,pimg,cname,loc,SUBSTRING(des,1,80)as tdes from place p inner join category c on p.cid=c.cid")
    data=cur.fetchall()	
    return render_template("view_post.html",data=data)

@app.route('/view_detail_place/<string:id>',methods=['POST','GET'])
def view_detail_place(id):
    cur=mysql.connection.cursor()
    cur.execute("select pid,pname,pimg,cname,loc,des from place p inner join category c on p.cid=c.cid where p.pid=%s",(id,))
    data=cur.fetchone()	
    return render_template("view_detail_place.html",data=data)


@app.route('/delete_post/<string:poid>',methods=['GET','POST'])
def delete_post(poid):
    cur=mysql.connection.cursor()
    cur.execute("delete from post where poid=%s",(poid,))
    mysql.connection.commit()
    cur.close()
    return redirect(url_for("view_post"))    
    
    
@app.route('/view_friends',methods=['POST','GET'])
def view_friends():
    cur=mysql.connection.cursor()
    cur.execute(" SELECT u.*  FROM user u inner JOIN request fr ON (u.ud = fr.tid AND fr.fid = %s OR u.ud = fr.fid AND fr.tid = %s) WHERE fr.status = 'Accepted' ",(
    session["ud"],session["ud"]))
    data=cur.fetchall()	
    return render_template("view_friends.html",data=data) 
	
@app.route('/view_recom_post',methods=['POST','GET'])
def view_recom_post():
    cur=mysql.connection.cursor()
    cur.execute(" SELECT u.*,p.* FROM user u JOIN request fr ON (u.ud = fr.tid AND fr.fid = %s OR u.ud = fr.fid AND fr.tid = %s) inner join post p on p.ud=u.ud WHERE fr.status = 'Accepted'",(session["ud"],session["ud"]))
    posts=cur.fetchall()	
    
    # Fetch reviews and calculate average rating
    for post in posts:
        cur.execute("SELECT cmrating FROM comments WHERE poid = %s", (post['poid'],))
        reviews = cur.fetchall()
        if reviews:
            avg_rating = round((sum([r['cmrating'] for r in reviews]) / len(reviews)),1)
        else:
            avg_rating = None
        post['avg_rating'] = avg_rating
        
        
    return render_template("view_recom_post.html",posts=posts)
    
@app.route('/view_recomm_detail_place/<string:id>',methods=['POST','GET'])
def view_recomm_detail_place(id):
    cur=mysql.connection.cursor()
    cur.execute("select * from post  where  poid=%s",(id,))
    data=cur.fetchone()	
    
    cur.execute("SELECT round((sum(cmrating)/count(cmrating)),1) as rate FROM comments WHERE poid = %s", (id,))
    reviews = cur.fetchone()
   
        
    if request.method=='POST':
        cmstar=request.form['cmstar']
        cmt=request.form['cmt']
        cur=mysql.connection.cursor()
        cur.execute("INSERT INTO `comments`(`uid`, `poid`, `cmt`, `cmrating`, `cmdate`) values(%s,%s,%s,%s,NOW())" ,(session["ud"],id,cmt,cmstar))
        mysql.connection.commit()
        cur.close()
        flash('Review Submitted Successfully','success')
    
    cur=mysql.connection.cursor()
    cur.execute("select * from comments c inner join user u on  c.uid=u.ud where c.poid=%s",(id,))
    data1=cur.fetchall()
    
    return render_template("view_recomm_detail_place.html",data=data,data1=data1,reviews=reviews)
    

@app.route('/view_user_post',methods=['POST','GET'])
def view_user_post():
    cur=mysql.connection.cursor()
    cur.execute("select * from post p inner join user u on p.ud=u.ud where u.ud")
    data=cur.fetchall()	
    return render_template("view_user_posts.html",data=data)	
		

@app.route('/remove_friend/<string:rid>',methods=['GET','POST'])
def remove_friend(rid):
    cur=mysql.connection.cursor()
    cur.execute("delete from request where rid=%s",(rid,))
    mysql.connection.commit()
    cur.close()
    return redirect(url_for("view_friends"))


@app.route('/reg',methods=['POST','GET'])
def reg():
    if request.method=='POST':
        if request.form["submit"]=="Submit":
            name=request.form['name']
            email=request.form['uemail']
            phone=request.form['phone']
            password=request.form['upass']
            loc=request.form['loc']
            cur=mysql.connection.cursor()
            cur.execute("INSERT INTO user(name,uemail,phone,upass,loc) values(%s,%s,%s,%s,%s)" ,(name,email,phone,password,loc))
            mysql.connection.commit()
            cur.close()
            flash('User Added Successfully','success')
    return render_template("reg.html")

@app.route('/login',methods=['POST','GET'])
def login():
    if request.method=='POST':
        if request.form["submit"]=="Login":
            name=request.form['uname']
            password=request.form['upass']
            cur=mysql.connection.cursor()
            cur.execute("select * from user where name=%s  and upass=%s",(name,password))
            data=cur.fetchone()
            if data:
                session['logged_in']=True
                session['ud']=data["ud"]
                session['name']=data["name"]
                flash('Login Successfully','success')
                return redirect('user_home')
            else:
                flash('Invalid Login. Try Again','danger')
    return render_template("login.html")

@app.route('/user_settings',methods=['POST','GET'])
def user_settings():
	if request.method=='POST':
		if request.form['submit']=='Submit':  
			npass=request.form['npass']
			cpass=request.form['cpass']
			cur=mysql.connection.cursor()
			if npass==cpass:
				cur.execute("update `user` set  `upass`=%s where ud=%s",(npass,session['ud']))
				mysql.connection.commit()
				cur.close()
				flash('Password Updated','info')
			else:
				flash('New password and conform password must be same','danger')
	return render_template("user_settings.html")
 
 
#check if user logged in
def is_logged_in(f):
	@wraps(f)
	def wrap(*args,**kwargs):
		if 'logged_in' in session:
			return f(*args,**kwargs)
		else:
			flash('Unauthorized, Please Login','danger')
			return redirect(url_for('index'))
	return wrap

#logout
@app.route("/logout")
def logout():
	session.clear()
	flash('You are now logged out','success')
	return redirect(url_for('login'))
	
if __name__=='__main__':
    app.secret_key='secret123'
    app.run(debug=True)	