-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2024 at 09:53 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_tourism`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(11) NOT NULL,
  `aname` varchar(150) NOT NULL,
  `apass` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `aname`, `apass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cid` int(11) NOT NULL,
  `cname` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cid`, `cname`) VALUES
(1, 'Beach'),
(2, 'Park');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `cmid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `poid` int(11) NOT NULL,
  `cmt` text NOT NULL,
  `cmrating` int(11) NOT NULL,
  `cmdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`cmid`, `uid`, `poid`, `cmt`, `cmrating`, `cmdate`) VALUES
(1, 2, 3, 'Very nice', 0, '2024-08-07'),
(2, 2, 3, 'Very nice', 0, '2024-08-07'),
(3, 2, 3, 'Very nice', 0, '2024-08-07'),
(4, 2, 3, 'Very nice', 0, '2024-08-07'),
(5, 2, 3, 'adsa', 2, '2024-08-07'),
(6, 2, 3, 'sadsadsa', 5, '2024-08-07'),
(7, 2, 1, '789', 3, '2024-08-08'),
(8, 2, 1, 'aewe', 5, '2024-08-08'),
(9, 2, 4, 'ererwe', 1, '2024-08-08');

-- --------------------------------------------------------

--
-- Table structure for table `place`
--

CREATE TABLE `place` (
  `pid` int(11) NOT NULL,
  `pname` varchar(150) NOT NULL,
  `cid` int(11) NOT NULL,
  `loc` varchar(150) NOT NULL,
  `des` text NOT NULL,
  `pimg` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `place`
--

INSERT INTO `place` (`pid`, `pname`, `cid`, `loc`, `des`, `pimg`) VALUES
(1, 'Arambol Beach', 1, 'Goa', 'One of the most beautiful beaches in North Goa, Arambol or Harmal Beach is a must-see on your holiday in the state. The beach has a distinct Bohmenian and laid-back vibe, probably because it was once a popular hippie beach in Goa. Arambol a silvery sand beach that also has rocks making it look quite stunning. It is also one of the greenest beaches in Goa.\n\n', '50424..png'),
(2, 'Mudumalai National Park', 2, 'Nilgiri ', 'The Mudumalai National Park or Wildlife Sanctuary resides on the northwestern side of the Nilgiri Hills (Blue Mountains), in Nilgiri District, about 150 km north-west of Coimbatore city in Kongu Nadu region of Tamil Nadu. By sharing its boundaries with the states of Karnataka and Kerala, the sanctuary is divided into 5 ranges – Masinagudi, Thepakadu, Mudumalai, Kargudi and Nellakota.', '10693..jpg');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `poid` int(11) NOT NULL,
  `ud` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `pdate` date NOT NULL,
  `ptitle` varchar(100) NOT NULL,
  `pimage` varchar(1000) NOT NULL,
  `desp` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`poid`, `ud`, `cid`, `pdate`, `ptitle`, `pimage`, `desp`) VALUES
(1, 1, 1, '2024-05-28', 'Arambol Beach', '47330..jpg', 'Nice to enjoying beach'),
(3, 1, 2, '2024-05-29', 'Gir National Park', '40392..jpg', 'Gir National Park is the only place in the world outside Africa where a lion can be seen in its natural habitat. The lions of Gir are a majestic animal, averaging 2.75 metres in length, and with a bigger tail tassle, bushier elbow tufs and prominent belly folds than his African cousin which has larger mane. Gir is a home to 40 species of mammals and 425 species of birds.Besides Africa, Gir National Park in Gujarat is the only place in the world where you can spot lions roaming free in the wild. The real discovery channel of India is situated approximately 65 Kms South East of Junagarh District. The Government notified the large geographical extent of Sasan Gir as wildlife sanctuary on 18th September, 1965 in order to conserve the Asiatic Lion. It covers total area of 1412 square kilometers of which 258 Km forms the core area of the National Park. Indiscriminate hunting by the people of Junagarh led to their decrease in population drastically, while they were completely wiped out from the other parts of Asia. It was the kind effort of Nawabs of Junagarh who protected the queen royalty in his own private hunting grounds. Later in due course of time Department of Forest Officials came forward to protect the world’s most threatened species. From a population of approximately 20 lions in 1913, they have risen to a comfortable 523 according to 2015 census. There are 106 male, 201 female and 213 sub-adult lions in the wilderness of these four districts.\n\n\n'),
(4, 1, 1, '2024-08-07', 'Arambol Beach', '87512..jpg', 'One of the most beautiful beaches in North Goa, Arambol or Harmal Beach is a must-see on your holiday in the state. The beach has a distinct Bohmenian and laid-back vibe, probably because it was once a popular hippie beach in Goa. Arambol a silvery sand beach that also has rocks making it look quite stunning. It is also one of the greenest beaches in Goa. The beach is also known for its festivals like Arambol Festival or Freak Festival in February; Arambol World Music Festival and The Tantra Festival in January.\r\n\r\n\r\n\r\n'),
(5, 2, 1, '2024-08-07', 'Arambol Beach', '28095..jpg', 'One of the most beautiful beaches in North Goa, Arambol or Harmal Beach is a must-see on your holiday in the state. The beach has a distinct Bohmenian and laid-back vibe, probably because it was once a popular hippie beach in Goa. Arambol a silvery sand beach that also has rocks making it look quite stunning. It is also one of the greenest beaches in Goa. The beach is also known for its festivals like Arambol Festival or Freak Festival in February; Arambol World Music Festival and The Tantra Festival in January.\r\n\r\n\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `rid` int(11) NOT NULL,
  `fid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `rdate` date NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `request`
--

INSERT INTO `request` (`rid`, `fid`, `tid`, `rdate`, `status`) VALUES
(2, 2, 1, '2024-07-30', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ud` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `uemail` varchar(100) NOT NULL,
  `phone` varchar(150) NOT NULL,
  `upass` varchar(150) NOT NULL,
  `loc` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ud`, `name`, `uemail`, `phone`, `upass`, `loc`) VALUES
(1, 'Sam', 'sam@gmail.com', '9845405688', '123', 'Goa'),
(2, 'Ram', 'ram@gmail.com', '9945605688', '123', 'Hyderabad'),
(3, 'Sara', 'saraa@gmail.com', '9945605688', '123', 'Mumbai'),
(4, 'Kala', 'kala@gail.com', '9874563210', '123', 'Salem');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`cmid`);

--
-- Indexes for table `place`
--
ALTER TABLE `place`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`poid`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ud`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `cmid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `place`
--
ALTER TABLE `place`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `poid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ud` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
